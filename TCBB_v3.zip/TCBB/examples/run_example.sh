#!/bin/bash
# Example: Run sequence design on example structure

# Ensure you have installed the package:
# pip install -e .

# Run design with default settings
python ../scripts/design_seq.py example.pdb \
    --heavy H \
    --light L \
    --config ../configs/test/bfn_testset.yml \
    --device cpu \
    --num_samples 1

# For stochastic (diverse) sampling:
# python ../scripts/design_seq.py example.pdb \
#     --heavy H --light L \
#     --config ../configs/test/bfn_testset.yml \
#     --device cuda --stochastic --num_samples 5
