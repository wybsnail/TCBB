"""
Geometric Constraints for Antibody CDR Generation.

Adapted from ABFlow (Antibody Normalizing Flow) paper.
Implements soft constraints using Huber-style penalty functions.

Constraints:
1. Bond Length: Adjacent CA-CA distance (η₁ ≤ D_{i,i+1} ≤ η₂)
2. Terminal Distance: CDR loop closure (ε₁ ≤ D_{first,last} ≤ ε₂)
3. Triangle Inequality: Distance matrix validity
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


# CDR-specific constraint parameters from ABFlow paper
# η₁, η₂: min/max adjacent CA distance (Angstrom)
# ε₁, ε₂: min/max terminal distance (Angstrom)
CDR_CONSTRAINTS = {
    'H_CDR1': {'eta1': 3.76, 'eta2': 3.84, 'eps1': 11.4, 'eps2': 13.1},
    'H_CDR2': {'eta1': 3.76, 'eta2': 3.87, 'eps1': 5.0,  'eps2': 5.9},
    'H_CDR3': {'eta1': 3.71, 'eta2': 3.88, 'eps1': 6.5,  'eps2': 8.5},
    'L_CDR1': {'eta1': 3.76, 'eta2': 3.85, 'eps1': 10.0, 'eps2': 12.0},
    'L_CDR2': {'eta1': 3.76, 'eta2': 3.85, 'eps1': 4.5,  'eps2': 5.5},
    'L_CDR3': {'eta1': 3.76, 'eta2': 3.85, 'eps1': 7.0,  'eps2': 9.0},
    # Default fallback
    'default': {'eta1': 3.71, 'eta2': 3.88, 'eps1': 5.0,  'eps2': 10.0},
}


def huber_constraint(y, a, b, delta=0.5):
    """
    Huber-style soft constraint function.
    
    Returns 0 when y is in [a, b], otherwise applies a smooth penalty:
    - Quadratic for small violations (< delta)
    - Linear for large violations (>= delta)
    
    Args:
        y: Input tensor
        a: Lower bound
        b: Upper bound
        delta: Huber transition threshold
    
    Returns:
        Penalty tensor (same shape as y)
    """
    # Violations below lower bound
    below = torch.clamp(a - y, min=0)
    # Violations above upper bound  
    above = torch.clamp(y - b, min=0)
    
    # Huber-style: quadratic for small, linear for large
    loss_below = torch.where(
        below < delta,
        0.5 * below ** 2 / delta,
        below - 0.5 * delta
    )
    loss_above = torch.where(
        above < delta,
        0.5 * above ** 2 / delta,
        above - 0.5 * delta
    )
    
    return loss_below + loss_above


def bond_length_constraint(pos, mask_gen, eta1=3.71, eta2=3.88, delta=0.5):
    """
    Bond length constraint: Adjacent CA-CA distance should be in [η₁, η₂].
    
    Typical CA-CA distance is ~3.8 Å for peptide bonds.
    
    Args:
        pos: (N, L, 3) CA coordinates
        mask_gen: (N, L) boolean mask for generated (CDR) residues
        eta1: Minimum allowed distance
        eta2: Maximum allowed distance
        delta: Huber threshold
    
    Returns:
        Scalar loss
    """
    # Distance between consecutive residues: (N, L-1)
    dist = torch.norm(pos[:, 1:] - pos[:, :-1], dim=-1)
    
    # Mask: both residues must be in CDR region
    mask = mask_gen[:, 1:] & mask_gen[:, :-1]
    
    # Apply Huber constraint
    loss = huber_constraint(dist, eta1, eta2, delta)
    
    # Average over valid pairs
    return (loss * mask.float()).sum() / (mask.sum().float() + 1e-8)


def terminal_distance_constraint(pos, mask_gen, eps1=5.0, eps2=10.0, delta=1.0):
    """
    Terminal distance constraint: CDR loop should close properly.
    
    The distance between first and last CDR residue should be in [ε₁, ε₂].
    This ensures the loop can connect back to the framework regions.
    
    Args:
        pos: (N, L, 3) CA coordinates
        mask_gen: (N, L) boolean mask for generated (CDR) residues
        eps1: Minimum terminal distance
        eps2: Maximum terminal distance
        delta: Huber threshold
    
    Returns:
        Scalar loss
    """
    N, L, _ = pos.shape
    losses = []
    
    for i in range(N):
        # Find CDR region boundaries
        cdr_mask = mask_gen[i]
        if cdr_mask.sum() < 2:
            continue
            
        # Get indices of CDR residues
        cdr_indices = torch.where(cdr_mask)[0]
        first_idx = cdr_indices[0]
        last_idx = cdr_indices[-1]
        
        # Distance between first and last CDR residue
        dist = torch.norm(pos[i, last_idx] - pos[i, first_idx])
        
        # Apply constraint
        loss = huber_constraint(dist, eps1, eps2, delta)
        losses.append(loss)
    
    if losses:
        return torch.stack(losses).mean()
    return torch.tensor(0.0, device=pos.device)


def triangle_inequality_constraint(pos, mask_gen, margin=0.1):
    """
    Triangle inequality constraint for distance matrix validity.
    
    For any three points i, j, k: D_ik <= D_ij + D_jk
    Violations indicate geometrically impossible configurations.
    
    Args:
        pos: (N, L, 3) CA coordinates
        mask_gen: (N, L) boolean mask for generated residues
        margin: Slack margin for soft constraint
    
    Returns:
        Scalar loss
    """
    N, L, _ = pos.shape
    
    if L < 3:
        return torch.tensor(0.0, device=pos.device)
    
    # Compute pairwise distances
    dist = torch.cdist(pos, pos)  # (N, L, L)
    
    # Sample triplets efficiently (avoid O(L³))
    # Check for consecutive triplets and some longer-range ones
    violations = []
    
    for offset in [1, 2, 3, 5]:
        if L <= 2 * offset:
            continue
            
        # Triplets: (i, i+offset, i+2*offset)
        i_idx = torch.arange(L - 2 * offset, device=pos.device)
        j_idx = i_idx + offset
        k_idx = i_idx + 2 * offset
        
        # Gather distances
        d_ij = dist[:, i_idx, j_idx]  # (N, num_triplets)
        d_jk = dist[:, j_idx, k_idx]
        d_ik = dist[:, i_idx, k_idx]
        
        # Triangle inequality: d_ik <= d_ij + d_jk
        # Violation: d_ik - d_ij - d_jk > margin
        violation = torch.clamp(d_ik - d_ij - d_jk - margin, min=0)
        
        # Mask: all three points should be in CDR
        mask_i = mask_gen[:, i_idx]
        mask_j = mask_gen[:, j_idx]
        mask_k = mask_gen[:, k_idx]
        mask = mask_i & mask_j & mask_k
        
        masked_violation = (violation * mask.float()).sum() / (mask.sum().float() + 1e-8)
        violations.append(masked_violation)
    
    if violations:
        return torch.stack(violations).mean()
    return torch.tensor(0.0, device=pos.device)


def chirality_constraint(pos, mask_gen):
    """
    Chirality constraint: Ensure correct L-amino acid handedness.
    
    Uses the sign of the triple product of consecutive CA vectors
    to detect chirality violations.
    
    Args:
        pos: (N, L, 3) CA coordinates
        mask_gen: (N, L) boolean mask
    
    Returns:
        Scalar loss penalizing wrong chirality
    """
    if pos.size(1) < 4:
        return torch.tensor(0.0, device=pos.device)
    
    # Vectors between consecutive CAs
    v1 = pos[:, 1:-2] - pos[:, :-3]   # (N, L-3, 3)
    v2 = pos[:, 2:-1] - pos[:, 1:-2]
    v3 = pos[:, 3:] - pos[:, 2:-1]
    
    # Triple product (should be positive for L-amino acids)
    cross = torch.cross(v1, v2, dim=-1)
    triple = (cross * v3).sum(dim=-1)  # (N, L-3)
    
    # Penalize negative triple products
    loss = F.relu(-triple)
    
    # Mask
    mask = mask_gen[:, 1:-2] & mask_gen[:, 2:-1] & mask_gen[:, 3:]
    
    return (loss * mask.float()).sum() / (mask.sum().float() + 1e-8)


class GeometricConstraints(nn.Module):
    """
    Geometric constraints module for antibody CDR generation.
    
    Combines multiple soft constraints to encourage physically valid structures.
    Can be used during training (as auxiliary loss) or inference (as post-processing).
    
    Usage:
        constraints = GeometricConstraints({'bond': 1.0, 'terminal': 0.5})
        loss_dict = constraints(pred_pos, mask_gen, cdr_type='H_CDR3')
    """
    
    def __init__(self, weights=None):
        """
        Args:
            weights: Dict of constraint weights, e.g.:
                {'bond': 1.0, 'terminal': 1.0, 'triangle': 0.1, 'chirality': 0.1}
        """
        super().__init__()
        self.weights = weights or {}
        
    def forward(self, pos, mask_gen, cdr_type=None):
        """
        Compute geometric constraint losses.
        
        Args:
            pos: (N, L, 3) CA coordinates (in Angstrom)
            mask_gen: (N, L) boolean mask for CDR residues
            cdr_type: Optional CDR type string (H_CDR1, H_CDR3, etc.)
                      Used to select appropriate constraint parameters.
        
        Returns:
            Dict of constraint losses (already weighted)
        """
        losses = {}
        
        # Get CDR-specific parameters
        params = CDR_CONSTRAINTS.get(cdr_type, CDR_CONSTRAINTS['default'])
        
        # 1. Bond length constraint
        if self.weights.get('bond', 0) > 0:
            losses['constraint_bond'] = bond_length_constraint(
                pos, mask_gen, 
                eta1=params['eta1'], 
                eta2=params['eta2']
            ) * self.weights['bond']
        
        # 2. Terminal distance constraint
        if self.weights.get('terminal', 0) > 0:
            losses['constraint_terminal'] = terminal_distance_constraint(
                pos, mask_gen,
                eps1=params['eps1'],
                eps2=params['eps2']
            ) * self.weights['terminal']
        
        # 3. Triangle inequality constraint
        if self.weights.get('triangle', 0) > 0:
            losses['constraint_triangle'] = triangle_inequality_constraint(
                pos, mask_gen
            ) * self.weights['triangle']
        
        # 4. Chirality constraint
        if self.weights.get('chirality', 0) > 0:
            losses['constraint_chirality'] = chirality_constraint(
                pos, mask_gen
            ) * self.weights['chirality']
        
        return losses
    
    def total_loss(self, pos, mask_gen, cdr_type=None):
        """Compute total constraint loss (sum of all components)."""
        losses = self.forward(pos, mask_gen, cdr_type)
        return sum(losses.values()) if losses else torch.tensor(0.0, device=pos.device)


# Convenience function for quick constraint checking
def check_structure_validity(pos, mask_gen=None, cdr_type='H_CDR3', verbose=True):
    """
    Check if a generated structure satisfies geometric constraints.
    
    Args:
        pos: (L, 3) or (N, L, 3) CA coordinates
        mask_gen: Optional mask for CDR region
        cdr_type: CDR type for parameter lookup
        verbose: Print violation details
    
    Returns:
        Dict with validity metrics
    """
    if pos.dim() == 2:
        pos = pos.unsqueeze(0)
    
    N, L, _ = pos.shape
    
    if mask_gen is None:
        mask_gen = torch.ones(N, L, dtype=torch.bool, device=pos.device)
    
    params = CDR_CONSTRAINTS.get(cdr_type, CDR_CONSTRAINTS['default'])
    
    # Bond lengths
    bond_dist = torch.norm(pos[:, 1:] - pos[:, :-1], dim=-1)
    bond_valid = (bond_dist >= params['eta1']) & (bond_dist <= params['eta2'])
    
    # Terminal distance
    cdr_indices = torch.where(mask_gen[0])[0]
    if len(cdr_indices) >= 2:
        term_dist = torch.norm(pos[0, cdr_indices[-1]] - pos[0, cdr_indices[0]])
        term_valid = (term_dist >= params['eps1']) & (term_dist <= params['eps2'])
    else:
        term_dist = torch.tensor(0.0)
        term_valid = True
    
    results = {
        'bond_distances': bond_dist,
        'bond_valid_ratio': bond_valid.float().mean().item(),
        'terminal_distance': term_dist.item(),
        'terminal_valid': bool(term_valid),
    }
    
    if verbose:
        print(f"=== Structure Validity Check ({cdr_type}) ===")
        print(f"Bond lengths: {bond_dist.min():.2f} - {bond_dist.max():.2f} Å")
        print(f"  Valid range: [{params['eta1']}, {params['eta2']}] Å")
        print(f"  Valid ratio: {results['bond_valid_ratio']*100:.1f}%")
        print(f"Terminal distance: {term_dist.item():.2f} Å")
        print(f"  Valid range: [{params['eps1']}, {params['eps2']}] Å")
        print(f"  Valid: {results['terminal_valid']}")
    
    return results


def compute_constraint_gradient(pos, mask_gen, cdr_type='H_CDR3', weights=None):
    """
    Compute gradient of constraint loss w.r.t. positions.
    
    Used for constraint-guided sampling during inference.
    
    Args:
        pos: (N, L, 3) CA coordinates (requires_grad=True)
        mask_gen: (N, L) boolean mask for CDR residues
        cdr_type: CDR type for parameter lookup
        weights: Dict of constraint weights
    
    Returns:
        grad: (N, L, 3) gradient of constraint loss
        loss: scalar constraint loss value
    """
    weights = weights or {'bond': 1.0, 'terminal': 0.5, 'triangle': 0.1}
    
    pos_grad = pos.detach().clone().requires_grad_(True)
    
    gc = GeometricConstraints(weights)
    loss_dict = gc(pos_grad, mask_gen, cdr_type=cdr_type)
    total_loss = sum(loss_dict.values())
    
    if total_loss.requires_grad:
        total_loss.backward()
        grad = pos_grad.grad
    else:
        grad = torch.zeros_like(pos)
    
    return grad, total_loss.item()


def refine_structure(pos, mask_gen, cdr_type='H_CDR3', 
                     num_steps=50, lr=0.1, weights=None, verbose=False):
    """
    Post-processing refinement to satisfy geometric constraints.
    
    Uses gradient descent to minimize constraint violations while
    preserving the overall structure.
    
    Args:
        pos: (N, L, 3) CA coordinates
        mask_gen: (N, L) boolean mask for CDR residues
        cdr_type: CDR type for parameter lookup
        num_steps: Number of optimization steps
        lr: Learning rate for gradient descent
        weights: Dict of constraint weights
        verbose: Print progress
    
    Returns:
        refined_pos: (N, L, 3) refined CA coordinates
        info: Dict with refinement statistics
    """
    weights = weights or {'bond': 10.0, 'terminal': 5.0, 'triangle': 1.0}
    
    # Clone and enable gradients only for CDR positions
    refined = pos.detach().clone()
    
    # Create learnable parameters for CDR positions
    N, L, _ = pos.shape
    cdr_pos = refined[mask_gen].clone().requires_grad_(True)
    
    optimizer = torch.optim.Adam([cdr_pos], lr=lr)
    
    gc = GeometricConstraints(weights)
    
    initial_loss = None
    final_loss = None
    
    for step in range(num_steps):
        optimizer.zero_grad()
        
        # Update refined positions
        refined_step = refined.clone()
        refined_step[mask_gen] = cdr_pos
        
        # Compute constraint loss
        loss_dict = gc(refined_step, mask_gen, cdr_type=cdr_type)
        total_loss = sum(loss_dict.values())
        
        if step == 0:
            initial_loss = total_loss.item()
        
        if total_loss.item() < 1e-4:
            if verbose:
                print(f"  Converged at step {step}")
            break
        
        # Backward and update
        total_loss.backward()
        optimizer.step()
        
        if verbose and step % 10 == 0:
            print(f"  Step {step}: loss = {total_loss.item():.4f}")
    
    final_loss = total_loss.item()
    
    # Apply final refined CDR positions
    refined[mask_gen] = cdr_pos.detach()
    
    info = {
        'initial_loss': initial_loss,
        'final_loss': final_loss,
        'improvement': (initial_loss - final_loss) / (initial_loss + 1e-8) * 100,
        'num_steps': step + 1,
    }
    
    if verbose:
        print(f"  Refinement: {info['initial_loss']:.4f} -> {info['final_loss']:.4f} "
              f"({info['improvement']:.1f}% improvement)")
    
    return refined, info


def constraint_guided_update(pred_pos, mask_gen, guidance_scale=0.1, cdr_type='H_CDR3'):
    """
    Apply constraint guidance during BFN sampling.
    
    Computes gradient of constraint loss and applies a small correction
    to the predicted positions to nudge them toward valid configurations.
    
    Args:
        pred_pos: (N, L, 3) predicted CA coordinates
        mask_gen: (N, L) boolean mask for CDR residues
        guidance_scale: Scale of the constraint gradient correction
        cdr_type: CDR type for parameter lookup
    
    Returns:
        guided_pos: (N, L, 3) positions with constraint guidance applied
    """
    weights = {'bond': 1.0, 'terminal': 0.5, 'triangle': 0.1}
    
    grad, loss = compute_constraint_gradient(pred_pos, mask_gen, cdr_type, weights)
    
    # Apply negative gradient (minimize constraint loss)
    # Only update CDR positions
    correction = -guidance_scale * grad
    correction = correction * mask_gen.unsqueeze(-1).float()
    
    guided_pos = pred_pos - correction
    
    return guided_pos

