#!/usr/bin/env python
"""
数据准备脚本 - antibodyflow
自动下载并处�?SAbDab 抗体结构数据�?

用法:
    python prepare_data.py                      # 自动下载并处�?
    python prepare_data.py --download-only      # 仅下�?
    python prepare_data.py --process-only       # 仅处�?
"""

import os
import sys
import argparse
import requests
import zipfile
import gzip
import shutil
import time
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

try:
    from tqdm import tqdm
except ImportError:
    print("Installing tqdm...")
    os.system(f"{sys.executable} -m pip install tqdm -q")
    from tqdm import tqdm

try:
    import pandas as pd
except ImportError:
    print("Installing pandas...")
    os.system(f"{sys.executable} -m pip install pandas -q")
    import pandas as pd

# 项目根目�?
PROJECT_ROOT = Path(__file__).parent
DATA_DIR = PROJECT_ROOT / "data"

# SAbDab URLs
SABDAB_SUMMARY_URL = "https://opig.stats.ox.ac.uk/webapps/newsabdab/sabdab/summary/all/"
SABDAB_SEARCH_URL = "https://opig.stats.ox.ac.uk/webapps/newsabdab/sabdab/search/"
RCSB_PDB_URL = "https://files.rcsb.org/download/{}.pdb"


def create_directories():
    """创建必要的目录结�?""
    dirs = [
        DATA_DIR,
        DATA_DIR / "all_structures" / "chothia",
        DATA_DIR / "processed",
    ]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)
    print(f"�?数据目录已创�? {DATA_DIR}")


def download_file(url, dest_path, desc=None, timeout=30):
    """下载文件并显示进度条"""
    try:
        response = requests.get(url, stream=True, timeout=timeout)
        response.raise_for_status()
        total_size = int(response.headers.get('content-length', 0))
        
        with open(dest_path, 'wb') as f:
            if total_size == 0:
                f.write(response.content)
            else:
                with tqdm(total=total_size, unit='iB', unit_scale=True, 
                         desc=desc, leave=False) as pbar:
                    for chunk in response.iter_content(chunk_size=8192):
                        f.write(chunk)
                        pbar.update(len(chunk))
        return True
    except Exception as e:
        if dest_path.exists():
            dest_path.unlink()
        return False


def download_sabdab_summary():
    """下载 SAbDab 摘要文件"""
    summary_path = DATA_DIR / "sabdab_summary_all.tsv"
    
    if summary_path.exists():
        print(f"�?摘要文件已存�? {summary_path}")
        return summary_path
    
    print("\n📥 下载 SAbDab 摘要文件...")
    
    # 尝试直接下载
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    try:
        response = requests.get(SABDAB_SUMMARY_URL, headers=headers, timeout=60)
        response.raise_for_status()
        
        with open(summary_path, 'wb') as f:
            f.write(response.content)
        
        # 验证文件
        df = pd.read_csv(summary_path, sep='\t')
        print(f"�?摘要文件下载成功: {len(df)} 条记�?)
        return summary_path
        
    except Exception as e:
        print(f"�?直接下载失败: {e}")
        print("  正在尝试备用方法...")
        
        # 备用: 使用搜索API
        try:
            search_url = f"{SABDAB_SEARCH_URL}?all=true&output=tsv"
            response = requests.get(search_url, headers=headers, timeout=120)
            response.raise_for_status()
            
            with open(summary_path, 'wb') as f:
                f.write(response.content)
            
            df = pd.read_csv(summary_path, sep='\t')
            print(f"�?摘要文件下载成功 (备用方法): {len(df)} 条记�?)
            return summary_path
            
        except Exception as e2:
            print(f"�?备用方法也失�? {e2}")
            return None


def download_single_pdb(pdb_code, chothia_dir, max_retries=3):
    """下载单个 PDB 文件"""
    pdb_path = chothia_dir / f"{pdb_code}.pdb"
    
    if pdb_path.exists():
        return pdb_code, "exists"
    
    # �?RCSB PDB 下载
    url = RCSB_PDB_URL.format(pdb_code.upper())
    
    for attempt in range(max_retries):
        try:
            response = requests.get(url, timeout=30)
            if response.status_code == 200:
                with open(pdb_path, 'wb') as f:
                    f.write(response.content)
                return pdb_code, "downloaded"
            elif response.status_code == 404:
                return pdb_code, "not_found"
            else:
                time.sleep(1)
        except Exception as e:
            if attempt < max_retries - 1:
                time.sleep(2)
            else:
                return pdb_code, f"error: {e}"
    
    return pdb_code, "failed"


def download_pdb_structures(summary_path, max_workers=8, limit=None):
    """并行下载 PDB 结构文件"""
    chothia_dir = DATA_DIR / "all_structures" / "chothia"
    
    # 读取摘要文件获取 PDB codes
    df = pd.read_csv(summary_path, sep='\t')
    pdb_codes = df['pdb'].unique().tolist()
    
    if limit:
        pdb_codes = pdb_codes[:limit]
    
    # 检查已存在的文�?
    existing = set(p.stem.lower() for p in chothia_dir.glob("*.pdb"))
    to_download = [p for p in pdb_codes if p.lower() not in existing]
    
    print(f"\n📥 下载 PDB 结构文件...")
    print(f"   总数: {len(pdb_codes)}")
    print(f"   已存�? {len(existing)}")
    print(f"   待下�? {len(to_download)}")
    
    if not to_download:
        print("�?所有结构文件已存在")
        return True
    
    # 并行下载
    downloaded = 0
    not_found = 0
    errors = 0
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(download_single_pdb, pdb, chothia_dir): pdb 
            for pdb in to_download
        }
        
        with tqdm(total=len(to_download), desc="Downloading PDBs") as pbar:
            for future in as_completed(futures):
                pdb_code, status = future.result()
                if status == "downloaded":
                    downloaded += 1
                elif status == "not_found":
                    not_found += 1
                elif status.startswith("error"):
                    errors += 1
                pbar.update(1)
    
    print(f"\n�?下载完成:")
    print(f"   成功下载: {downloaded}")
    print(f"   未找�? {not_found}")
    print(f"   错误: {errors}")
    
    return True


def verify_data():
    """验证数据完整�?""
    print("\n🔍 验证数据...")
    
    summary_path = DATA_DIR / "sabdab_summary_all.tsv"
    chothia_dir = DATA_DIR / "all_structures" / "chothia"
    
    # 检查摘要文�?
    if summary_path.exists():
        df = pd.read_csv(summary_path, sep='\t')
        print(f"�?摘要文件: {len(df)} 条记�?)
        total_pdbs = df['pdb'].nunique()
    else:
        print(f"�?摘要文件不存�? {summary_path}")
        return False
    
    # 检查结构文�?
    if chothia_dir.exists():
        pdb_files = list(chothia_dir.glob("*.pdb"))
        print(f"�?PDB 结构文件: {len(pdb_files)} / {total_pdbs}")
        
        coverage = len(pdb_files) / total_pdbs * 100
        print(f"  覆盖�? {coverage:.1f}%")
        
        if coverage < 50:
            print("  �?覆盖率较低，建议继续下载")
    else:
        print(f"�?结构目录不存�?)
        return False
    
    return True


def process_data():
    """预处理数�?""
    print("\n�?预处理数�?..")
    print("  这可能需�?30-60 分钟...")
    
    sys.path.insert(0, str(PROJECT_ROOT))
    
    try:
        from antibodyflow.datasets.sabdab import SAbDabDataset
        
        print("  正在处理数据�?(首次运行会建立LMDB缓存)...")
        train_dataset = SAbDabDataset(
            summary_path=str(DATA_DIR / "sabdab_summary_all.tsv"),
            chothia_dir=str(DATA_DIR / "all_structures" / "chothia"),
            processed_dir=str(DATA_DIR / "processed"),
            split='train',
            reset=True,
        )
        print(f"  �?训练�? {len(train_dataset)} 样本")
        
        val_dataset = SAbDabDataset(
            summary_path=str(DATA_DIR / "sabdab_summary_all.tsv"),
            chothia_dir=str(DATA_DIR / "all_structures" / "chothia"),
            processed_dir=str(DATA_DIR / "processed"),
            split='val',
        )
        print(f"  �?验证�? {len(val_dataset)} 样本")
        
        print("\n�?数据预处理完�?")
        return True
        
    except ImportError as e:
        print(f"�?导入失败: {e}")
        print("  请先安装依赖: pip install -e .")
        return False
    except Exception as e:
        print(f"�?处理失败: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    parser = argparse.ArgumentParser(description="antibodyflow 数据准备")
    parser.add_argument('--download-only', action='store_true', help='仅下载数�?)
    parser.add_argument('--process-only', action='store_true', help='仅处理数�?)
    parser.add_argument('--limit', type=int, default=None, help='限制下载PDB数量(用于测试)')
    parser.add_argument('--workers', type=int, default=8, help='下载并行�?)
    args = parser.parse_args()
    
    print("=" * 60)
    print("🧬 antibodyflow 数据准备")
    print("=" * 60)
    
    create_directories()
    
    if not args.process_only:
        # 下载摘要文件
        summary_path = download_sabdab_summary()
        if summary_path is None:
            print("\n�?无法下载摘要文件，请手动下载")
            return
        
        # 下载 PDB 结构
        download_pdb_structures(
            summary_path, 
            max_workers=args.workers,
            limit=args.limit
        )
    
    # 验证
    if not verify_data():
        return
    
    if not args.download_only:
        # 处理数据
        process_data()
    
    print("\n" + "=" * 60)
    print("�?数据准备完成!")
    print("=" * 60)
    print("""
下一�?
  1. 训练模型:
     python train.py configs/train/bfn_seq_design.yml

  2. 设计序列:
     python design_seq.py 7DK2_AB_C_chothia.pdb --config configs/test/bfn_testset.yml
""")


if __name__ == "__main__":
    main()
