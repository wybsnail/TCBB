# Data Directory

This directory should contain the training and evaluation data. Due to size constraints, data files are not included in the repository.

## Directory Structure

```
data/
├── README.md                   # This file
├── sabdab_summary_all.tsv      # SAbDab database summary (downloaded)
├── all_structures/
│   └── chothia/                # Chothia-numbered PDB files
└── processed/                  # Preprocessed LMDB cache (auto-generated)
```

## Data Preparation

### Step 1: Download SAbDab Summary

The summary file will be automatically downloaded when running the data preparation script. Alternatively, you can download it manually:

```bash
# Manual download (optional)
wget -O data/sabdab_summary_all.tsv "http://opig.stats.ox.ac.uk/webapps/sabdab-sabpred/sabdab/summary/all/"
```

### Step 2: Download PDB Structures

The data preparation script will automatically download structures from SAbDab/RCSB:

```bash
python scripts/prepare_data.py --download
```

Or download manually from [SAbDab](http://opig.stats.ox.ac.uk/webapps/sabdab-sabpred/sabdab):
1. Visit the SAbDab website
2. Download all structures with Chothia numbering
3. Extract to `data/all_structures/chothia/`

### Step 3: Preprocessing

After downloading, preprocess the data to create LMDB cache:

```bash
python scripts/prepare_data.py --chothia_dir data/all_structures/chothia
```

This creates an efficient LMDB cache in `data/processed/` for training.

## Full Automatic Preparation

Run everything with a single command:

```bash
python scripts/prepare_data.py --download --chothia_dir data/all_structures/chothia
```

## Test Set

For evaluation, prepare a CSV file with columns:
- `pdb`: PDB ID
- `Hchain`: Heavy chain ID
- `Lchain`: Light chain ID

Example: `test_set.csv`

## Notes

- The full dataset requires ~15GB of disk space
- Data download may take several hours depending on network speed
- LMDB preprocessing takes ~30-60 minutes
